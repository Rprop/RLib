var class_system_1_1_local_object =
[
    [ "LocalObject", "dd/d1c/class_system_1_1_local_object.html#a4dad15517774250a8817a54390e6160e", null ]
];