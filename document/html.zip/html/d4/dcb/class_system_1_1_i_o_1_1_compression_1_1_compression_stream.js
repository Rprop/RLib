var class_system_1_1_i_o_1_1_compression_1_1_compression_stream =
[
    [ "CompressionStream", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#a47de4da62fec66476596f143e26babd1", null ],
    [ "~CompressionStream", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#acb51ef86ce74623d80372db710d54ad2", null ],
    [ "__declspec", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#ad379685a2b158d37a8638ba8b803adfe", null ],
    [ "__declspec", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#a8899e01b673644c99c793d85a2e1ebfd", null ],
    [ "Close", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#adc76e6c32677bfe28a598ef768f9f700", null ],
    [ "Flush", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#aff335b6d0cbddcf2ab3067d4dcd70164", null ],
    [ "GetBaseStream", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#a37eacdb3d3105c1f8c096f52772b0142", null ],
    [ "GetCanRead", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#a6b4f9c9e1bcfde19f88a4e7f1977b506", null ],
    [ "Read", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#a8097a72e705623a20789305650bad2fc", null ],
    [ "Write", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#abd4fb1b31b919263e34d44f879e04466", null ],
    [ "m_buffer", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#afc94bb94cf33b4ebb16148883c3b4164", null ],
    [ "m_external_struct", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#a124a5969c86402a90b2c79f8740fbbfc", null ],
    [ "m_gzip_header_flag", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#a0eac622a1dbfbf3d78cccbbe0e7dcdb5", null ],
    [ "m_mode", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#a06230ccb8c7d4214b65c1db8a7812ef4", null ],
    [ "m_underlying_stream", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html#ad499fef76120c5a97678eae17c577de8", null ]
];