var namespace_system_1_1_collections =
[
    [ "Generic", "d9/d1b/namespace_system_1_1_collections_1_1_generic.html", "d9/d1b/namespace_system_1_1_collections_1_1_generic" ],
    [ "Allocator", "d8/d9b/class_system_1_1_collections_1_1_allocator.html", "d8/d9b/class_system_1_1_collections_1_1_allocator" ],
    [ "HashMap", "df/da9/class_system_1_1_collections_1_1_hash_map.html", "df/da9/class_system_1_1_collections_1_1_hash_map" ]
];