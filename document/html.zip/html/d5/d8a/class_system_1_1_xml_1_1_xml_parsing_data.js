var class_system_1_1_xml_1_1_xml_parsing_data =
[
    [ "Cursor", "d5/d8a/class_system_1_1_xml_1_1_xml_parsing_data.html#a7da4db8d419663c1a73714787060de31", null ],
    [ "Stamp", "d5/d8a/class_system_1_1_xml_1_1_xml_parsing_data.html#a5b1399180afd8dc320734a199c0eec1a", null ],
    [ "XmlDocument", "d5/d8a/class_system_1_1_xml_1_1_xml_parsing_data.html#acb499a895285d52060e9d6f2d937d383", null ]
];