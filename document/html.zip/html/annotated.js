var annotated =
[
    [ "System", "d8/dd0/namespace_system.html", "d8/dd0/namespace_system" ],
    [ "_IO_STATUS_BLOCK_STRUCT", "dd/dc6/struct___i_o___s_t_a_t_u_s___b_l_o_c_k___s_t_r_u_c_t.html", "dd/dc6/struct___i_o___s_t_a_t_u_s___b_l_o_c_k___s_t_r_u_c_t" ],
    [ "_OBJECT_ATTRIBUTES_STRUCT", "d3/df7/struct___o_b_j_e_c_t___a_t_t_r_i_b_u_t_e_s___s_t_r_u_c_t.html", "d3/df7/struct___o_b_j_e_c_t___a_t_t_r_i_b_u_t_e_s___s_t_r_u_c_t" ],
    [ "_rlib_ssl_info", "d5/d38/struct__rlib__ssl__info.html", "d5/d38/struct__rlib__ssl__info" ],
    [ "_UNICODE_STRING_STRUCT", "de/d90/struct___u_n_i_c_o_d_e___s_t_r_i_n_g___s_t_r_u_c_t.html", "de/d90/struct___u_n_i_c_o_d_e___s_t_r_i_n_g___s_t_r_u_c_t" ],
    [ "MD5Context", "d3/d3c/struct_m_d5_context.html", "d3/d3c/struct_m_d5_context" ]
];