var _r_lib___net_8h =
[
    [ "Uri", "d9/d49/struct_system_1_1_net_1_1_uri.html", "d9/d49/struct_system_1_1_net_1_1_uri" ],
    [ "WebHeaderCollection", "dc/dde/struct_system_1_1_net_1_1_web_header_collection.html", "dc/dde/struct_system_1_1_net_1_1_web_header_collection" ],
    [ "LPURI", "d3/d86/_r_lib___net_8h.html#a18482d519ba35578512c0a49d401da45", null ],
    [ "WebHeader", "d3/d86/_r_lib___net_8h.html#af417c38a59cf2af1280dcf3022d2d584", null ],
    [ "DecompressionMethods", "d3/d86/_r_lib___net_8h.html#a1091935b0315abde6a9b9b398b92149d", [
      [ "None", "d3/d86/_r_lib___net_8h.html#a1091935b0315abde6a9b9b398b92149dacb307356c9dedf1339e7d449b61d8a48", null ],
      [ "GZip", "d3/d86/_r_lib___net_8h.html#a1091935b0315abde6a9b9b398b92149dab0b1eaf384b09a8bdbf341f39c2d5ea1", null ],
      [ "Deflate", "d3/d86/_r_lib___net_8h.html#a1091935b0315abde6a9b9b398b92149da2926598bbf51724e598db954dd81fcba", null ],
      [ "Auto", "d3/d86/_r_lib___net_8h.html#a1091935b0315abde6a9b9b398b92149da568a2e4b2cd4f6251e3bdeeb036e9eb5", null ]
    ] ]
];