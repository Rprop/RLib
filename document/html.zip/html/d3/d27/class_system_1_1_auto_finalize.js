var class_system_1_1_auto_finalize =
[
    [ "AutoFinalize", "d3/d27/class_system_1_1_auto_finalize.html#a369e5f1914144439f2da624ab9345de2", null ],
    [ "~AutoFinalize", "d3/d27/class_system_1_1_auto_finalize.html#a7b0709da934e00aefed1fb3be3458e2f", null ],
    [ "argv", "d3/d27/class_system_1_1_auto_finalize.html#ab4a2216fc4d0adb453a226970ad99b76", null ],
    [ "finalizer", "d3/d27/class_system_1_1_auto_finalize.html#a4edfcaf5a417e0ae2cfd86ca02e127b1", null ]
];