var struct_m_d5_context =
[
    [ "buffer", "d3/d3c/struct_m_d5_context.html#adb656cb8790c884aa02e1080145e2391", null ],
    [ "count", "d3/d3c/struct_m_d5_context.html#a25dcfc21366858a476c2a96d4c8a9de9", null ],
    [ "state", "d3/d3c/struct_m_d5_context.html#a6e3fa7c25a95510c63f8b30eceb7b14f", null ]
];