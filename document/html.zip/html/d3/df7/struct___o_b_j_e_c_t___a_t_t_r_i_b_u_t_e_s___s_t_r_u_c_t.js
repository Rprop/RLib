var struct___o_b_j_e_c_t___a_t_t_r_i_b_u_t_e_s___s_t_r_u_c_t =
[
    [ "Attributes", "d3/df7/struct___o_b_j_e_c_t___a_t_t_r_i_b_u_t_e_s___s_t_r_u_c_t.html#aebc6aedae1e1aae36517b0d62cb980aa", null ],
    [ "Length", "d3/df7/struct___o_b_j_e_c_t___a_t_t_r_i_b_u_t_e_s___s_t_r_u_c_t.html#a7f0f53fe12a9990ae603fbd46434fe39", null ],
    [ "ObjectName", "d3/df7/struct___o_b_j_e_c_t___a_t_t_r_i_b_u_t_e_s___s_t_r_u_c_t.html#a1e87b79aaf8333cb8060e67aa676a9df", null ],
    [ "RootDirectory", "d3/df7/struct___o_b_j_e_c_t___a_t_t_r_i_b_u_t_e_s___s_t_r_u_c_t.html#af5279550e2d3e92cebb58bf1f7e59561", null ],
    [ "SecurityDescriptor", "d3/df7/struct___o_b_j_e_c_t___a_t_t_r_i_b_u_t_e_s___s_t_r_u_c_t.html#aedf66e83b732c9fa407abc29338ee0b6", null ],
    [ "SecurityQualityOfService", "d3/df7/struct___o_b_j_e_c_t___a_t_t_r_i_b_u_t_e_s___s_t_r_u_c_t.html#a7a336f80f5967a4bc498c75ac7cc28bb", null ]
];