var _r_lib___variant_8h =
[
    [ "Variant", "d5/d87/class_system_1_1_variant.html", "d5/d87/class_system_1_1_variant" ],
    [ "IntegerVariant", "d0/dfa/class_system_1_1_integer_variant.html", "d0/dfa/class_system_1_1_integer_variant" ],
    [ "Long", "d8/de4/class_system_1_1_long.html", "d8/de4/class_system_1_1_long" ],
    [ "ULong", "d9/df0/class_system_1_1_u_long.html", "d9/df0/class_system_1_1_u_long" ],
    [ "Int32", "d9/dbd/class_system_1_1_int32.html", "d9/dbd/class_system_1_1_int32" ],
    [ "UInt32", "d9/d24/class_system_1_1_u_int32.html", "d9/d24/class_system_1_1_u_int32" ],
    [ "Float", "d6/d45/class_system_1_1_float.html", "d6/d45/class_system_1_1_float" ],
    [ "Double", "d7/d13/class_system_1_1_double.html", "d7/d13/class_system_1_1_double" ],
    [ "_MAX_VAR_BIT_LENGHT", "dc/dc0/_r_lib___variant_8h.html#a1235050289f8c8329e9a5eb374029789", null ],
    [ "ToInt32", "dc/dc0/_r_lib___variant_8h.html#a83d2633069b375d02a00262d825962b5", null ],
    [ "ToInt32Ptr", "dc/dc0/_r_lib___variant_8h.html#a3a907f92f61f4826e696885cf8b81094", null ],
    [ "ToUInt32", "dc/dc0/_r_lib___variant_8h.html#a9c76626b4ce5af2537113882091778db", null ],
    [ "ToUInt32Ptr", "dc/dc0/_r_lib___variant_8h.html#a3b3d27bd7b9aedc3833844c1b97303ed", null ],
    [ "Boolean", "dc/dc0/_r_lib___variant_8h.html#adeceef0bfefda6bc270a7179dc858174", null ],
    [ "Byte", "dc/dc0/_r_lib___variant_8h.html#a59d94afc6c802ebb26ec02e84c77bab7", null ],
    [ "Void", "dc/dc0/_r_lib___variant_8h.html#a1a88de9c5b1402e1a04dd252316644a8", null ]
];