var namespace_system_1_1_i_o =
[
    [ "Compression", "d6/d80/namespace_system_1_1_i_o_1_1_compression.html", "d6/d80/namespace_system_1_1_i_o_1_1_compression" ],
    [ "_MEMORY_INFORMATION", "d6/d46/struct_system_1_1_i_o_1_1___m_e_m_o_r_y___i_n_f_o_r_m_a_t_i_o_n.html", "d6/d46/struct_system_1_1_i_o_1_1___m_e_m_o_r_y___i_n_f_o_r_m_a_t_i_o_n" ],
    [ "BufferedStream", "de/d77/class_system_1_1_i_o_1_1_buffered_stream.html", "de/d77/class_system_1_1_i_o_1_1_buffered_stream" ],
    [ "Directory", "d8/dcb/class_system_1_1_i_o_1_1_directory.html", null ],
    [ "File", "dd/db1/class_system_1_1_i_o_1_1_file.html", "dd/db1/class_system_1_1_i_o_1_1_file" ],
    [ "FileStream", "d3/dd4/class_system_1_1_i_o_1_1_file_stream.html", "d3/dd4/class_system_1_1_i_o_1_1_file_stream" ],
    [ "MemoryAllocator", "d4/de7/class_system_1_1_i_o_1_1_memory_allocator.html", null ],
    [ "MemoryPage", "da/d74/class_system_1_1_i_o_1_1_memory_page.html", "da/d74/class_system_1_1_i_o_1_1_memory_page" ],
    [ "MemoryPool", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool" ],
    [ "MemoryStream", "df/d95/class_system_1_1_i_o_1_1_memory_stream.html", "df/d95/class_system_1_1_i_o_1_1_memory_stream" ],
    [ "Path", "d3/de7/struct_system_1_1_i_o_1_1_path.html", "d3/de7/struct_system_1_1_i_o_1_1_path" ],
    [ "Stream", "d4/d75/class_system_1_1_i_o_1_1_stream.html", "d4/d75/class_system_1_1_i_o_1_1_stream" ],
    [ "StreamReader", "d9/dea/class_system_1_1_i_o_1_1_stream_reader.html", "d9/dea/class_system_1_1_i_o_1_1_stream_reader" ],
    [ "UnmanagedMemoryStream", "df/d6e/class_system_1_1_i_o_1_1_unmanaged_memory_stream.html", "df/d6e/class_system_1_1_i_o_1_1_unmanaged_memory_stream" ]
];