var struct_system_1_1_net_1_1_web_header_collection =
[
    [ "WebHeaderCollection", "dc/dde/struct_system_1_1_net_1_1_web_header_collection.html#ab3f3ec164a2ac5637bd005f169c74ac7", null ],
    [ "~WebHeaderCollection", "dc/dde/struct_system_1_1_net_1_1_web_header_collection.html#a9f83e842dfd2d9721fff4db67dacd794", null ],
    [ "Add", "dc/dde/struct_system_1_1_net_1_1_web_header_collection.html#a6cd165336a6e5fd255f6d1d8eae3ce62", null ],
    [ "Clear", "dc/dde/struct_system_1_1_net_1_1_web_header_collection.html#ac22ef604e1ac5249cc9aa6fe9d999ba2", null ],
    [ "Get", "dc/dde/struct_system_1_1_net_1_1_web_header_collection.html#af5705f1d43c447bb8b8cf42ae3a015e3", null ],
    [ "ToByteArray", "dc/dde/struct_system_1_1_net_1_1_web_header_collection.html#aa47e2d4da61b3ad572b964b62e4e5a35", null ],
    [ "WriteByteArray", "dc/dde/struct_system_1_1_net_1_1_web_header_collection.html#a36bf35f7c913b199ea2cd64ca07dd20d", null ],
    [ "Count", "dc/dde/struct_system_1_1_net_1_1_web_header_collection.html#ac2680507e2253286c44b218b1ab3107f", null ],
    [ "RLIB_DECLARE_DYNCREATE", "dc/dde/struct_system_1_1_net_1_1_web_header_collection.html#a41fea0b45bb9c0ca7c236dbe86f5370d", null ]
];