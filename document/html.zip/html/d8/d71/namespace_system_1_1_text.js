var namespace_system_1_1_text =
[
    [ "Encoder", "d0/d00/class_system_1_1_text_1_1_encoder.html", null ]
];