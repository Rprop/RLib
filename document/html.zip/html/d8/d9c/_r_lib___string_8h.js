var _r_lib___string_8h =
[
    [ "String", "db/d0b/class_system_1_1_string.html", "db/d0b/class_system_1_1_string" ],
    [ "string", "d8/d9c/_r_lib___string_8h.html#ad64423a7f6d6b5755aa13b69835fc9b4", null ],
    [ "Nullable", "d8/d9c/_r_lib___string_8h.html#a8cefe83e374d8096b9f46f256f161162", [
      [ "Nothing", "d8/d9c/_r_lib___string_8h.html#a8cefe83e374d8096b9f46f256f161162a61764f0a311c19df443ec923e7d4c6d7", null ]
    ] ],
    [ "operator+", "d8/d9c/_r_lib___string_8h.html#a106664b8cb72db0bfa4a5d606b35913f", null ],
    [ "operator+", "d8/d9c/_r_lib___string_8h.html#a5775128ad1c9a73f81ddf4aa9b78af36", null ],
    [ "StringArray", "d8/d9c/_r_lib___string_8h.html#ad03b451ed16400b0dec96e60ebffcccb", null ]
];