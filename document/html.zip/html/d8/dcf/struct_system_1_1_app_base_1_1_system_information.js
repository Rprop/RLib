var struct_system_1_1_app_base_1_1_system_information =
[
    [ "ActiveProcessors", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html#a675389274a529602e2f3f9fd125aa4d7", null ],
    [ "AllocationGranularity", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html#a485590e85e4cf2d2a81fb39670cc844c", null ],
    [ "HighestPhysicalPage", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html#a37321cf8f12ce1769b9a45920d164613", null ],
    [ "HighestUserAddress", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html#a8e9d8a9b06eb96daeecb1e4b8dd3bbc4", null ],
    [ "LowestPhysicalPage", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html#a8adf29b84b1fbe49d51aa89fc1652552", null ],
    [ "LowestUserAddress", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html#aaff4ef88a32cae79f232fab8da913fe3", null ],
    [ "MaximumIncrement", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html#afd22e663b815d7eb777c68d8ce3de065", null ],
    [ "NumberOfPhysicalPages", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html#a43c77f38e6b3df447aff461c5fb4d971", null ],
    [ "NumberProcessors", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html#abf23842b8d4cf0605b1e0c0ebd9fd6d3", null ],
    [ "PhysicalPageSize", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html#aff3442a5437390e8dbcc49e430824973", null ],
    [ "Unknown", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html#aa17da6b7eabc9b17c216d17d36ffba4b", null ]
];