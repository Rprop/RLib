var struct_system_1_1_big_int_1_1_big_int_div_result =
[
    [ "a", "da/db3/struct_system_1_1_big_int_1_1_big_int_div_result.html#a0f20379d9aa886965106c858a8127a59", null ],
    [ "b", "da/db3/struct_system_1_1_big_int_1_1_big_int_div_result.html#a2eb151d8b62322ee5de4d4071d0ebd37", null ]
];