var class_system_1_1_app_base =
[
    [ "SystemInformation", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html", "d8/dcf/struct_system_1_1_app_base_1_1_system_information" ]
];