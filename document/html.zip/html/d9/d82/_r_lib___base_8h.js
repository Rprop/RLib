var _r_lib___base_8h =
[
    [ "AppBase", "da/d80/class_system_1_1_app_base.html", "da/d80/class_system_1_1_app_base" ],
    [ "SystemInformation", "d8/dcf/struct_system_1_1_app_base_1_1_system_information.html", "d8/dcf/struct_system_1_1_app_base_1_1_system_information" ],
    [ "MemoryPool", "d9/d82/_r_lib___base_8h.html#a5fcd2b28dbd1c64191db3baecccba034", null ]
];