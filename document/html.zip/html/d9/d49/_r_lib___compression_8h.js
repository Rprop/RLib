var _r_lib___compression_8h =
[
    [ "CompressionStream", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream" ],
    [ "CompressionLevel", "d9/d49/_r_lib___compression_8h.html#a893de1c505bb182c7f2569c6efafe394", [
      [ "DefaultCompression", "d9/d49/_r_lib___compression_8h.html#a893de1c505bb182c7f2569c6efafe394ab5cfbb575532e32f373d7acfb313acb6", null ],
      [ "NoCompression", "d9/d49/_r_lib___compression_8h.html#a893de1c505bb182c7f2569c6efafe394a6b8a4df3dddcef4649c2c5abfa829334", null ],
      [ "BestSpeed", "d9/d49/_r_lib___compression_8h.html#a893de1c505bb182c7f2569c6efafe394a9921a84c5fcabc135fd322cef4fc4857", null ],
      [ "BestCompression", "d9/d49/_r_lib___compression_8h.html#a893de1c505bb182c7f2569c6efafe394aa5b1c8fa42458bf2977e2f8f6d7da1fe", null ]
    ] ],
    [ "CompressionMode", "d9/d49/_r_lib___compression_8h.html#af6199e6ebe44c5e821f5149b7d2390ad", [
      [ "DecompressMode", "d9/d49/_r_lib___compression_8h.html#af6199e6ebe44c5e821f5149b7d2390ada9426d4f836fe919b23c63ad3a3ec42dd", null ],
      [ "CompressMode", "d9/d49/_r_lib___compression_8h.html#af6199e6ebe44c5e821f5149b7d2390ada6db7daaea2adef724af7fffb68e126df", null ]
    ] ]
];