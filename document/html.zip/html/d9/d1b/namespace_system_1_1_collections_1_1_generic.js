var namespace_system_1_1_collections_1_1_generic =
[
    [ "Array", "db/d4e/class_system_1_1_collections_1_1_generic_1_1_array.html", "db/d4e/class_system_1_1_collections_1_1_generic_1_1_array" ],
    [ "Comparable", "d2/d7a/class_system_1_1_collections_1_1_generic_1_1_comparable.html", "d2/d7a/class_system_1_1_collections_1_1_generic_1_1_comparable" ],
    [ "Disposable", "d6/d06/class_system_1_1_collections_1_1_generic_1_1_disposable.html", "d6/d06/class_system_1_1_collections_1_1_generic_1_1_disposable" ],
    [ "Hash", "db/dd8/class_system_1_1_collections_1_1_generic_1_1_hash.html", "db/dd8/class_system_1_1_collections_1_1_generic_1_1_hash" ],
    [ "HashTable", "db/d5a/class_system_1_1_collections_1_1_generic_1_1_hash_table.html", "db/d5a/class_system_1_1_collections_1_1_generic_1_1_hash_table" ],
    [ "List", "de/d52/class_system_1_1_collections_1_1_generic_1_1_list.html", "de/d52/class_system_1_1_collections_1_1_generic_1_1_list" ],
    [ "PriorityQueue", "d3/de2/class_system_1_1_collections_1_1_generic_1_1_priority_queue.html", "d3/de2/class_system_1_1_collections_1_1_generic_1_1_priority_queue" ],
    [ "Queue", "d0/d70/class_system_1_1_collections_1_1_generic_1_1_queue.html", "d0/d70/class_system_1_1_collections_1_1_generic_1_1_queue" ],
    [ "Stack", "d0/d97/class_system_1_1_collections_1_1_generic_1_1_stack.html", "d0/d97/class_system_1_1_collections_1_1_generic_1_1_stack" ]
];