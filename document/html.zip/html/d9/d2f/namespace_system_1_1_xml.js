var namespace_system_1_1_xml =
[
    [ "XmlAttribute", "d4/da5/class_system_1_1_xml_1_1_xml_attribute.html", "d4/da5/class_system_1_1_xml_1_1_xml_attribute" ],
    [ "XmlAttributeSet", "d4/da1/class_system_1_1_xml_1_1_xml_attribute_set.html", "d4/da1/class_system_1_1_xml_1_1_xml_attribute_set" ],
    [ "XmlBase", "d9/d54/class_system_1_1_xml_1_1_xml_base.html", "d9/d54/class_system_1_1_xml_1_1_xml_base" ],
    [ "XmlComment", "dd/d2e/class_system_1_1_xml_1_1_xml_comment.html", "dd/d2e/class_system_1_1_xml_1_1_xml_comment" ],
    [ "XmlCursor", "d2/dbe/struct_system_1_1_xml_1_1_xml_cursor.html", "d2/dbe/struct_system_1_1_xml_1_1_xml_cursor" ],
    [ "XmlDeclaration", "db/d6b/class_system_1_1_xml_1_1_xml_declaration.html", "db/d6b/class_system_1_1_xml_1_1_xml_declaration" ],
    [ "XmlDocument", "d1/d48/class_system_1_1_xml_1_1_xml_document.html", "d1/d48/class_system_1_1_xml_1_1_xml_document" ],
    [ "XmlElement", "d1/d1e/class_system_1_1_xml_1_1_xml_element.html", "d1/d1e/class_system_1_1_xml_1_1_xml_element" ],
    [ "XmlHandle", "d2/d13/class_system_1_1_xml_1_1_xml_handle.html", "d2/d13/class_system_1_1_xml_1_1_xml_handle" ],
    [ "XmlNode", "d7/d15/class_system_1_1_xml_1_1_xml_node.html", "d7/d15/class_system_1_1_xml_1_1_xml_node" ],
    [ "XmlParsingData", "d5/d8a/class_system_1_1_xml_1_1_xml_parsing_data.html", "d5/d8a/class_system_1_1_xml_1_1_xml_parsing_data" ],
    [ "XmlPrinter", "d8/d93/class_system_1_1_xml_1_1_xml_printer.html", "d8/d93/class_system_1_1_xml_1_1_xml_printer" ],
    [ "XmlText", "d1/db6/class_system_1_1_xml_1_1_xml_text.html", "d1/db6/class_system_1_1_xml_1_1_xml_text" ],
    [ "XmlUnknown", "d7/da4/class_system_1_1_xml_1_1_xml_unknown.html", "d7/da4/class_system_1_1_xml_1_1_xml_unknown" ],
    [ "XmlVisitor", "db/d6c/class_system_1_1_xml_1_1_xml_visitor.html", "db/d6c/class_system_1_1_xml_1_1_xml_visitor" ]
];