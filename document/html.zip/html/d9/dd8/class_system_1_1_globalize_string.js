var class_system_1_1_globalize_string =
[
    [ "GlobalizeString", "d9/dd8/class_system_1_1_globalize_string.html#af237bf983a4b144c35ed9ca936fafb99", null ],
    [ "GlobalizeString", "d9/dd8/class_system_1_1_globalize_string.html#a2a023576c138a303499700bcdbf2742c", null ],
    [ "~GlobalizeString", "d9/dd8/class_system_1_1_globalize_string.html#a51b15a4445f7eadb265688d7d33a669a", null ],
    [ "operator char *", "d9/dd8/class_system_1_1_globalize_string.html#af027354808c98903066ec52a8b68d4b4", null ],
    [ "operator wchar_t *", "d9/dd8/class_system_1_1_globalize_string.html#ac7d63c8b33ab833a8950a947ea49fabb", null ],
    [ "operator=", "d9/dd8/class_system_1_1_globalize_string.html#a51cfac0a8250d28c61d59d25a35c6cbc", null ],
    [ "operator=", "d9/dd8/class_system_1_1_globalize_string.html#a5a4a01f9bbac7664678a0e5c039bea92", null ],
    [ "release_all", "d9/dd8/class_system_1_1_globalize_string.html#a34ea173511383c411b30df44888669a0", null ],
    [ "RLIB_ALIGN", "d9/dd8/class_system_1_1_globalize_string.html#a6ef5b95aec6b64a2322abf935adeecd4", null ],
    [ "sizeofGBK", "d9/dd8/class_system_1_1_globalize_string.html#aa45d9af121a349a1413280d6981e76ab", null ],
    [ "sizeofUnicode", "d9/dd8/class_system_1_1_globalize_string.html#a0819b0182c5939f1fd52d3377bbdb801", null ],
    [ "sizeofUtf8", "d9/dd8/class_system_1_1_globalize_string.html#ad0f05e7ea14c6bb6e8d373497325887f", null ],
    [ "SuppressFinalize", "d9/dd8/class_system_1_1_globalize_string.html#a5570305f4463adcd5d5dabadd432249d", null ],
    [ "toGBK", "d9/dd8/class_system_1_1_globalize_string.html#af1c1e60f2a261e8cc39f0bf0be831a10", null ],
    [ "toString", "d9/dd8/class_system_1_1_globalize_string.html#a0d908a0a84a96d0682d84575f6158de6", null ],
    [ "toUnicode", "d9/dd8/class_system_1_1_globalize_string.html#a14569be531a7638f05f195314164d413", null ],
    [ "toUtf8", "d9/dd8/class_system_1_1_globalize_string.html#a4aec1a57657b338cc9f862547569ec7a", null ],
    [ "m_str", "d9/dd8/class_system_1_1_globalize_string.html#adda9ef6d18571a124d9bb46079a056bb", null ],
    [ "RLIB_DECLARE_DYNCREATE", "d9/dd8/class_system_1_1_globalize_string.html#a1f2673dbaa435e4b57f8652ed5a9a232", null ]
];