var _r_lib___config_8h =
[
    [ "_DISABLE_FILE_REG", "d9/d51/_r_lib___config_8h.html#a63049f2ad86c4947be5b62b6d212675e", null ],
    [ "_DISABLE_MAIL", "d9/d51/_r_lib___config_8h.html#a85c248e159d53062b63dd36ba654a006", null ],
    [ "_DISABLE_MP3", "d9/d51/_r_lib___config_8h.html#a92ba1ab614e1e52842ea1532d58404f9", null ],
    [ "_DISABLE_OBAMA64", "d9/d51/_r_lib___config_8h.html#a0eb62af5c4acb8b70cf1bf545ba20a96", null ],
    [ "_DISABLE_REGEXP", "d9/d51/_r_lib___config_8h.html#a614a1f5acbfae95817d735d7f6fa5d92", null ],
    [ "_DISABLE_TEXTSPEAKER", "d9/d51/_r_lib___config_8h.html#aca5a8003ca68ab7ac2790dce52877396", null ],
    [ "_DISABLE_UAC", "d9/d51/_r_lib___config_8h.html#af62becf18a024be5ee1cbaeb62b21491", null ]
];