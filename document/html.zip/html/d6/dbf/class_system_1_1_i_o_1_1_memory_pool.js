var class_system_1_1_i_o_1_1_memory_pool =
[
    [ "MEMORY_PAGE", "d8/dba/struct_system_1_1_i_o_1_1_memory_pool_1_1_m_e_m_o_r_y___p_a_g_e.html", "d8/dba/struct_system_1_1_i_o_1_1_memory_pool_1_1_m_e_m_o_r_y___p_a_g_e" ],
    [ "MEMORY_PAGE", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#adbafe4230f7ba89e466ea51b408e0fcc", null ],
    [ "PMEMPAGE", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#aba435351c42c2d92bb7f460be22cbe64", null ],
    [ "MemoryPool", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#a7c023ab5a24a850aab00df6c158942d4", null ],
    [ "~MemoryPool", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#ad8b0f8b22a35a1d36dfef323537beac5", null ],
    [ "AllocByte", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#a53dd281edb94d6370613be931a1b541a", null ],
    [ "Collect", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#acf706797b0afc245d4b0b8faa2388ba3", null ],
    [ "GetSize", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#ad7909e27c925e59236db3e26065b87e3", null ],
    [ "operator[]", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#a40c5ab08c14eb242acc62cd9108bca89", null ],
    [ "ReAlloc", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#a1f9dff0651a6c0e863703bc1d49ed58c", null ],
    [ "ReSize", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#a8104a8655499cdb52bdd8bffc7cac24b", null ],
    [ "TryGCCollect", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#a9b8789c6b75277b8ec3626f00a1babab", null ],
    [ "TryReAlloc", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#ab80814251e6067a0ef5a47637766675d", null ],
    [ "WaitForFullGCComplete", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#af68fa93c66ef23962161ec089ffd3ccc", null ],
    [ "MemoryCount", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#af0fa6bea7fed60f9e486675eb1fb3580", null ],
    [ "MemoryList", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#a188f3628d00234418be4664868a2ecbe", null ],
    [ "RLIB_DECLARE_DYNCREATE", "d6/dbf/class_system_1_1_i_o_1_1_memory_pool.html#a9e04b83844abf6e4bfeecd7cee3a3de2", null ]
];