var class_system_1_1_collections_1_1_generic_1_1_disposable =
[
    [ "IDisposable", "d6/d06/class_system_1_1_collections_1_1_generic_1_1_disposable.html#a5c566984987a0bc0973285ab22ae1355", null ]
];