var struct_system_1_1_i_o_1_1___m_e_m_o_r_y___i_n_f_o_r_m_a_t_i_o_n =
[
    [ "AllocationBase", "d6/d46/struct_system_1_1_i_o_1_1___m_e_m_o_r_y___i_n_f_o_r_m_a_t_i_o_n.html#a67f3b4b8ca457ab291509c88f70e34b0", null ],
    [ "AllocationProtect", "d6/d46/struct_system_1_1_i_o_1_1___m_e_m_o_r_y___i_n_f_o_r_m_a_t_i_o_n.html#ad71cbe81dfe180a814c2781ad4c03e56", null ],
    [ "BaseAddress", "d6/d46/struct_system_1_1_i_o_1_1___m_e_m_o_r_y___i_n_f_o_r_m_a_t_i_o_n.html#a43d885beadadc89d9e7cc50a718308c8", null ],
    [ "Protect", "d6/d46/struct_system_1_1_i_o_1_1___m_e_m_o_r_y___i_n_f_o_r_m_a_t_i_o_n.html#a62299106de57dd8dd69b769988d3df53", null ],
    [ "RegionSize", "d6/d46/struct_system_1_1_i_o_1_1___m_e_m_o_r_y___i_n_f_o_r_m_a_t_i_o_n.html#a30b0a98db4f324b8015bfc342de802cd", null ],
    [ "State", "d6/d46/struct_system_1_1_i_o_1_1___m_e_m_o_r_y___i_n_f_o_r_m_a_t_i_o_n.html#aeec0697e134071451d91905e81aaa92d", null ],
    [ "Type", "d6/d46/struct_system_1_1_i_o_1_1___m_e_m_o_r_y___i_n_f_o_r_m_a_t_i_o_n.html#ad4a765d0280cb799a5fa5d0974f2c2d8", null ]
];