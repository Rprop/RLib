var _r_lib___text_8h =
[
    [ "Encoder", "d0/d00/class_system_1_1_text_1_1_encoder.html", null ],
    [ "Encoding", "d6/d52/_r_lib___text_8h.html#acefe31680d1dffb11daf1490de078eed", [
      [ "UnknownEncoding", "d6/d52/_r_lib___text_8h.html#acefe31680d1dffb11daf1490de078eedaab84a48905c316f971eb35c79659f6a5", null ],
      [ "ASCIIEncoding", "d6/d52/_r_lib___text_8h.html#acefe31680d1dffb11daf1490de078eeda67e93ea2e4031c0016f73e0a22bc69ef", null ],
      [ "UTF8Encoding", "d6/d52/_r_lib___text_8h.html#acefe31680d1dffb11daf1490de078eeda946002f02dfcbef05e0ca3cbe12e42a5", null ],
      [ "UTF16Encoding", "d6/d52/_r_lib___text_8h.html#acefe31680d1dffb11daf1490de078eeda6741f13f8373ca2bd184fda5521493b0", null ],
      [ "UTF16FEncoding", "d6/d52/_r_lib___text_8h.html#acefe31680d1dffb11daf1490de078eedaa7f1cf3232e8fed4c04542ae00ff6024", null ]
    ] ]
];