var namespace_system_1_1_i_o_1_1_compression =
[
    [ "CompressionStream", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream.html", "d4/dcb/class_system_1_1_i_o_1_1_compression_1_1_compression_stream" ],
    [ "Deflate", "d5/dd8/class_system_1_1_i_o_1_1_compression_1_1_deflate.html", null ],
    [ "DeflateStream", "d5/dbc/class_system_1_1_i_o_1_1_compression_1_1_deflate_stream.html", "d5/dbc/class_system_1_1_i_o_1_1_compression_1_1_deflate_stream" ],
    [ "GZip", "d0/d49/class_system_1_1_i_o_1_1_compression_1_1_g_zip.html", null ],
    [ "GZipStream", "dd/dc3/class_system_1_1_i_o_1_1_compression_1_1_g_zip_stream.html", "dd/dc3/class_system_1_1_i_o_1_1_compression_1_1_g_zip_stream" ]
];