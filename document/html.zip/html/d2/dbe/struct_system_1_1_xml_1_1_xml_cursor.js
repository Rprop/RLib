var struct_system_1_1_xml_1_1_xml_cursor =
[
    [ "XmlCursor", "d2/dbe/struct_system_1_1_xml_1_1_xml_cursor.html#ac8df87099fe54fcba547b602a1136eb3", null ],
    [ "Clear", "d2/dbe/struct_system_1_1_xml_1_1_xml_cursor.html#a3a015e5d9ce0989c24f6602ae1c66454", null ],
    [ "col", "d2/dbe/struct_system_1_1_xml_1_1_xml_cursor.html#a088d0e1c2009d69231b9e17226af0e36", null ],
    [ "row", "d2/dbe/struct_system_1_1_xml_1_1_xml_cursor.html#a6aa35c3b8efa89567f976244b56f868f", null ]
];