var _r_lib___string_helper_8h =
[
    [ "StringCopyTo", "d2/d38/_r_lib___string_helper_8h.html#a314d92ece92243eb86a150e6a042abe8", null ],
    [ "StringCopyToA", "d2/d38/_r_lib___string_helper_8h.html#af6787a336da50dcd5d6e8eb30ee41721", null ],
    [ "StringReference", "d2/d38/_r_lib___string_helper_8h.html#aba03eee38d529c813e4a1b6b85dc53a9", null ],
    [ "StringStartWith", "d2/d38/_r_lib___string_helper_8h.html#a67bfc0c9c607d7bb46341b9a664296ce", null ],
    [ "StringStartWithA", "d2/d38/_r_lib___string_helper_8h.html#a0dea16296b4a079bce7701a9bfe8f80c", null ],
    [ "StringStartWithW", "d2/d38/_r_lib___string_helper_8h.html#a850c96a2f5a77d400529c4ac68be4a36", null ],
    [ "TLEN", "d2/d38/_r_lib___string_helper_8h.html#a706938fe8441115226ebf0e5191abd1a", null ],
    [ "TSIZE", "d2/d38/_r_lib___string_helper_8h.html#a0d5642bfdd7ad59b64e0b947b701f254", null ],
    [ "TSIZE_ALIGNED", "d2/d38/_r_lib___string_helper_8h.html#a9241ff9513791f6a20501f7c03c7f3f2", null ]
];