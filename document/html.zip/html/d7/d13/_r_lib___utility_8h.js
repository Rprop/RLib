var _r_lib___utility_8h =
[
    [ "RLIB_ENABLE_SHELLAPI", "d7/d13/_r_lib___utility_8h.html#a5ada5747644e94bff59160e7ecb20ad7", null ],
    [ "_tcsistr", "d7/d13/_r_lib___utility_8h.html#a9b444a65a3f866a9f87fa5016f03bede", null ],
    [ "round_up", "d7/d13/_r_lib___utility_8h.html#a953c4e0d58a7729cf630424ccadb60f1", null ],
    [ "round_up_4", "d7/d13/_r_lib___utility_8h.html#a2ad6e54499f3a940e973e43f7a4d83bc", null ],
    [ "round_up_8", "d7/d13/_r_lib___utility_8h.html#a26fa44bc48474f5f15951aac6b5cc83d", null ],
    [ "stristr", "d7/d13/_r_lib___utility_8h.html#a996a2a75af1ae3215829f9c0f5331aff", null ],
    [ "swap", "d7/d13/_r_lib___utility_8h.html#a8c13977c6dbca76aec49d9019231a040", null ],
    [ "swap", "d7/d13/_r_lib___utility_8h.html#a02cae1ff8d07762af4e7d10ca9a5424f", null ],
    [ "wcsistr", "d7/d13/_r_lib___utility_8h.html#aa1644d3a333d3b7d9dc3c863312f23a0", null ]
];