var namespace_system_1_1_net =
[
    [ "HTTP_CALLBACK_OBJECT", "dd/de4/struct_system_1_1_net_1_1_h_t_t_p___c_a_l_l_b_a_c_k___o_b_j_e_c_t.html", "dd/de4/struct_system_1_1_net_1_1_h_t_t_p___c_a_l_l_b_a_c_k___o_b_j_e_c_t" ],
    [ "HttpRequest", "df/d31/class_system_1_1_net_1_1_http_request.html", "df/d31/class_system_1_1_net_1_1_http_request" ],
    [ "HttpResponse", "d7/db8/class_system_1_1_net_1_1_http_response.html", "d7/db8/class_system_1_1_net_1_1_http_response" ],
    [ "Sockets", "db/d3d/class_system_1_1_net_1_1_sockets.html", "db/d3d/class_system_1_1_net_1_1_sockets" ],
    [ "Uri", "d9/d49/struct_system_1_1_net_1_1_uri.html", "d9/d49/struct_system_1_1_net_1_1_uri" ],
    [ "WebClient", "d7/d53/class_system_1_1_net_1_1_web_client.html", null ],
    [ "WebHeaderCollection", "dc/dde/struct_system_1_1_net_1_1_web_header_collection.html", "dc/dde/struct_system_1_1_net_1_1_web_header_collection" ]
];